import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const orders = {
  'KM12345': { id: 'KM12345', status: 'In Transit' },
  'KM98765': { id: 'KM98765', status: 'Delivered' },
  'KM54321': { id: 'KM54321', status: 'Processing' },
};

app.get('/', (req, res) => {
  res.send('K&M Exports Order Tracking API is running');
});

app.get('/orders/track/:id', (req, res) => {
  const orderId = req.params.id.toUpperCase();
  const order = orders[orderId];

  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  return res.json(order);
});

app.listen(PORT, () => {
  console.log(`✅ K&M Exports API running on port ${PORT}`);
});